// // Example data stored in an array
// const containerData = [
//     { logo: '<i class="fa-brands fa-html5"></i>', title: 'Container 1', text: 'This is the first dynamically added container.' },
//     { logo: '<i class="fa-brands fa-css3-alt"></i>', title: 'Container 2', text: 'This is the second dynamically added container.' },
//     { logo: '<i class="fa-brands fa-js"></i>', title: 'Container 3', text: 'This is the third dynamically added container.' }
// ];

// let currentIndex = 0; // Keeps track of the index for the next container to add

// document.getElementById('add-btn').addEventListener('click', function() {
//     if (currentIndex < containerData.length) {  // Check if there is more data in the array
//         // Create a new container
//         let newContainer = document.createElement('div');
//         newContainer.classList.add('dynamic-container');

//         // Add the logo
//         let logo = document.createElement('img');
//         logo.src = containerData[currentIndex].logo;  // Get logo from data
//         newContainer.appendChild(logo);

//         // Add an h1 tag
//         let h1 = document.createElement('h1');
//         h1.textContent = containerData[currentIndex].title;  // Get title from data
//         newContainer.appendChild(h1);

//         // Add a paragraph
//         let para = document.createElement('p');
//         para.textContent = containerData[currentIndex].text;  // Get text from data
//         newContainer.appendChild(para);

//         // Append the new container to the main container
//         document.getElementById('container').appendChild(newContainer);

//         currentIndex++;  // Increment the index to add the next container on the next click
//     } else {
//         alert('No more containers to add!');
//     }
// });#

const cssSkill = document.getElementById('html-skill');
const skillBar = document.querySelector('.skill-bar');
const label = document.getElementById('html-width-label');

const widthPercentage = (cssSkill.offsetWidth / skillBar.offsetWidth) * 100;
label.textContent = `css Skill: ${widthPercentage.toFixed(0)}%`;

 



